RUSS - RedIcon User Support System

- Easy to install, configure and maintain
- Tickets, Knowledge base, Video chat
- Integrated Caching and Backup Function
- Statistics, Private Messaging, Member2Member support
- Unlimited languages
- PHP/MySQL Powered

Website: http://redicon.eu

-----------------------------------------------------
	RUSS MANUAL SETUP README FILE
-----------------------------------------------------

Step-by-step instructions, assuming that you have already uploaded RUSS to your server. If not, first upload RUSS to your webserver, and then:

1. Unzip rumsy_manual_install somewhere on your PC

2. Open /install/db.sql with i.e. Notepad and insert your details. You should change:

('EMAIL_FROM_ADDR', 'youremail_INSERT_HERE@yourserver.info') with your email address and
('WEB_ROOT', 'http://path/to/rumsy/INSERT/HERE/') with path to RUSS folder.

3. Copy everything inside db.sql file (CTRL + A, CTRL + C) and open phpMyAdmin on your web server. Click on Database you have created for RUSS, then click on SQL tab and paste (CTRL + V) content from db.sql file inside textarea provided for SQL queries. Now click 'Go' below.
 
4. Open /admin/include/constants.php with i.e. Notepad and insert your details. You should change:

define('DB_SERVER', 'INSERT SERVER ADDRESS');   // MySQL Server address. Usually localhost
define('DB_USER', 'INSERT DB USERNAME');	// MySQL Database username
define('DB_PASS', 'INSERT DB PASSWORD');	// MySQL Database password
define('DB_NAME', 'INSERT DB NAME');	        // MySQL Database name
define('PATHER', 'INSERT PATH TO RUMSY');  	// PATH (i.e. : http://redicon.eu/demo/RUMSY)

5. Save and upload / overwrite constants.php on your server (inside /admin/include/) 

6. Delete /install/ folder.

7. Make sure /admin/cache/ and /admin/backup/ folders are writtable if you are on Linux server (CHMOD 0777)

8. Open your browser and go where you have installed RUSS. It should work now.

9. Check your admin section and if everything is O.K. If not, check if you did everything correct once again.

-----------------------------------------------------

If you have any questions, please open support ticket @ http://support.redicon.eu