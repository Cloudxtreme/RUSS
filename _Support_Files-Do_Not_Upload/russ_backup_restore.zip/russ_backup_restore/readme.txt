RUSS - RedIcon User Support System

- Easy to install, configure and maintain
- Tickets, Knowledge base, Video chat
- Integrated Caching and Backup Function
- Statistics, Private Messaging, Member2Member support
- Unlimited languages
- PHP/MySQL Powered

Website: http://redicon.eu

-----------------------------------------------------
	RUSS DATABASE RESTORE README FILE
-----------------------------------------------------

IMPORTANT: Your server MUST ALLOW EXEC command to be executed. Otherwise this script will not work. If your server doesn't allow EXEC, other option is to restore your *.db backup file with phpMyAdmin or similar software.

Step-by-step instructions:

1. Unzip rumsy_backup_restore somewhere on your PC

2. Open rumsy_backup_restore.php with i.e. Notepad and insert your database details.

3. Open your latest database backup file (*.sql) with Notepad and copy all the content. Now paste everything inside backup.sql file inside russ_backup_restore directory. Don't forget to save.

4. Upload russ_backup_restore directory to your web server. Best place would be your root folder.

5. Open your browser and go to:

http://yourdomainname.xxx/russ_backup_restore/russ_backup_restore.php

obviously replace yourdomainname.xxx with your domain name.

6. Your database should be restored. Check your admin section and if everything is O.K. delete folder russ_backup_restore from your server. If not, check if you did everything correct.

-----------------------------------------------------

If you have any questions, please open support ticket @ http://support.redicon.eu