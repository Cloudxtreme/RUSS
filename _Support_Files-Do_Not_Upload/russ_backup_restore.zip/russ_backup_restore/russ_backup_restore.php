<?php
// Demo reset

define('DB_SERVER', 'localhost');			// DATABASE SERVER ADDRESS
define('DB_USER', 'username');				// DATABASE USERNAME
define('DB_PASS', 'password');				// DATABASE PASSWORD
define('DB_NAME', 'database_name');			// DATABASE NAME
$mysqlImportFilename ='backup.sql';			// NAME OF DB BACKUP FILE

                  $command='mysql -h' .DB_SERVER.' -u' .DB_USER.' -p' .DB_PASS.' ' .DB_NAME.' < ' .$mysqlImportFilename;
                  $output=array();
                  exec($command,$output,$worked);

?>